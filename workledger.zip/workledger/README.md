# WorkLedger 📋
**Employee Attendance & Salary Calculator**

A clean, fast web app to track daily attendance and auto-calculate salaries — with PDF payslip export and persistent data storage.

---

## Features
- ✅ Daily attendance tracking (Present / Absent / Half Day / Leave)
- 💰 Monthly & hourly salary modes with auto calculation
- 📊 Payroll summary for all employees
- 🧾 PDF payslip export per employee or full team
- 💾 Data saved in browser — persists across sessions
- ➕ Add / delete employees
- ✏️ Edit salary on long press

---

## Deploy in 5 Steps (No coding needed)

### Step 1 — Create a GitHub account
Go to [github.com](https://github.com) and sign up for a free account.

### Step 2 — Create a new repository
1. Click the **+** button (top right) → **New repository**
2. Name it: `workledger`
3. Set it to **Public**
4. Click **Create repository**

### Step 3 — Upload the files
1. In your new repository, click **uploading an existing file**
2. Upload ALL files from this project folder, maintaining the folder structure:
   ```
   index.html
   package.json
   vite.config.js
   src/
     main.jsx
     App.jsx
   ```
3. Click **Commit changes**

### Step 4 — Enable GitHub Pages with GitHub Actions
1. Go to your repo → **Settings** → **Pages**
2. Under "Source", select **GitHub Actions**
3. GitHub will suggest a workflow — click **Configure** on the "Static HTML" one

   Or create the file `.github/workflows/deploy.yml` with this content:

```yaml
name: Deploy WorkLedger

on:
  push:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Setup Node
        uses: actions/setup-node@v3
        with:
          node-version: 18

      - name: Install & Build
        run: |
          npm install
          npm run build

      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

### Step 5 — Done! 🎉
After ~2 minutes, your app will be live at:
```
https://YOUR-USERNAME.github.io/workledger
```

Bookmark this URL — all your employee data saves in your browser automatically!

---

## Local Development (optional)

If you want to run it on your computer first:

```bash
# Install Node.js from nodejs.org first, then:
npm install
npm run dev
```

Open http://localhost:5173 in your browser.

---

## How data is saved
All employee records and attendance data are saved in your **browser's localStorage**. This means:
- ✅ Data persists when you close and reopen the tab
- ✅ Works offline once loaded
- ⚠️ Data is per-device and per-browser (not synced across devices)
- ⚠️ Clearing browser data will erase it — export PDFs regularly as backup
